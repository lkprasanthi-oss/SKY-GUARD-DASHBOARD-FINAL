const SOURCE_URL =
  'https://sky-guard-weather-dashboard--lpranavi24.replit.app/';

function App() {
  return (
    <iframe
      className="source-page"
      src={SOURCE_URL}
      title="SkyGuard Weather Dashboard"
    />
  );
}

export default App;